package day2;

// 실수

// 1. 숫자의 개수는 무한대 -> 컴퓨터로 저장할 수 없다
// 2. 정수의 경우는 범위를 잘라서(-100~100) 저장
// 3. 실수는 범위를 잘라도 무한대 -> 저장 불가능 -> 근사값을 저장
// 4.	float(4), double(8), long double
//		실수는 정밀도가 높아진다
public class Test4 {
	public static void main(String[]ar) {
		// 실수 연산은 오차가 발생할 수 있다
		// 1 - 0.7 -> 0.3 희망
		System.out.println(1 - 7 * 0.1);
	}
}
