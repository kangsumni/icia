package day2;

//변수와 literal
public class Test3 {
	// 리터럴 : 직접 적혀있는 값. 변경할 수 없는 값

	// 정수 리터럴도 정수다
	int a = 100;
	
	// 오른쪽에 있는 30억의 타입은?
	long b = 3000000000L;
	
	long c = 5000000000L;
}
