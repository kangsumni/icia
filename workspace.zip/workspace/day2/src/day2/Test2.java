package day2;

// 정수 타입
public class Test2 {
	public static void main(String[] ar) {
	// 정수 : byte(1), short(2), int(4), long(8)
	// 타입별로 저장할 수 있는 크기가 다르다	(타입별로 저장범위가 다르다)

	// int는 자바의 기본 정수로 대충 +-21억
	// long은 +-922경
	
	// 올해 매출액이 최대 12억정도...
	int machul = 1200000000 + 1200000000;
	System.out.println(machul);
	
	int a = 2000000000;
	int b = 2000000000;
	int c = 2000000000;
	}
}
