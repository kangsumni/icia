package day2;

// 1바이트는 8비트. 2의 8제곱으로 256개의 문자를 처리 가능
// 문자는 1바이트 문자와 2바이트 문자(한, 중, 일)
// 자바의 char는 2바이트
// 오라클의 데이터베이스의 문자는 3바이트
public class Test9 {
	public static void main(String[] args) {
		char ch = 'A';
		int a = ch;
		System.out.println(ch);			//'A'
		System.out.println(a);			//65
		
		char ch2 = (char)a;
	}
}
