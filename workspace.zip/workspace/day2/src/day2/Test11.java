package day2;

// 주민등록번호를 숫자로 저장하고자 한다. 이 값을 저장하기 위해서는 어떤 자료형
// (data type)을 선택해야 할까? regNo라는 이름의 변수를 선언하고 자신의 주민등록번호로
// 초기화 하는 한 줄의 코드를 적으시오
public class Test11 {
	public static void main(String[] ar) {
		long regNo = 990728;
		
//		System.out.println(“1” + “2”);
//		System.out.println(true + “”);
//		System.out.println(‘A' + 'B');
//		System.out.println('1' + 2);
//		System.out.println('1' + '2');
//		System.out.println('J' + “ava”);
//		System.out.println(true + null);
	}
}
