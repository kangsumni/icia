package day2;

public class Test7 {
	public static void main(String[] ar) {
		int totalcount = 123;
		int pageno = 2;
		int pagesize = 10;
		int blocksize = 5;
		
		// prev, start, end, next를 계산해 출력하시오
		// 0, 1, 5, 6
		int countOfpage = (totalcount-1)/pagesize+1;
//		System.out.println(countOfpage);
		int prev = (pageno-1)/blocksize*blocksize;
		int start = prev+1;
		int end = prev+blocksize;
		int next = end+1;
		
		if(end>=countOfpage) {
			end = countOfpage;
			next = 0;
		}
		
		System.out.println(prev+ " " +start+" "+end+" "+next);
	}
}
