package day2;

// js에서 전역, 지역.
// 전역 : 소속된 함수가 없다, 지역 : 함수소속

// 자바의 경우 
// 지역 : 함수 소속, 속성 : 클래스 소속(객체 소속)

public class Text12 {
	int x;			//필드 - 0으로 초기화
	public static void main(String[] ar) {
		float f = 3.14;
		double f2 = 3.14;
		
		int z;		// 지역변수 - 초기화
		
		// 자바에서 값이 없는 변수는 사용할 수 업다
		System.out.println(x);
		System.out.println(z);
		
	}
}
