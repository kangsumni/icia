package day2;

public class Test8 {
	public static void main(String[] ar) {
		// digital은 이진수로 저장하고 처리하는 기술
		int a = 48;			//'0'
		int b = 65;			//'A'
		int c = 97;			//'a'
		
		System.out.println(a);			    // 숫자 : 48
		System.out.println((char)a);		// 문자 : '0'
		
		for(int i = 65; i<=90; i++) {
			System.out.println((char)i);
		}
		
		char ch='A';
		
	}
}
