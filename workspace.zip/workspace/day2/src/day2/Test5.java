package day2;

// 타입 : byte, short, int, long, float, double, char <-> boolean

// 타입 변환 규칙
// 1. 결과가 숫자인 연산과 결과가 불리언인 연산은 섞어서 사용할 수 없다
// const a = (5>3)+(10>2);
// 2. 같은 타입을 연산하먄 결과도 그 타입
// 3. 다른 타입을 연산하면 표현범위가 넓은 타입(자동변환
public class Test5 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		float c= 3.14f;
//		a+b;	//long
//		a+c;	//float
//		b+c;	//float
		
		System.out.println(3/5);	//0 0.6 1
	}

}
