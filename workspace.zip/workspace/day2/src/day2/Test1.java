package day2;

// 자바의 장점 : programming once, run anywhere
// 자바 프로그램에서 윈도우가 실행하는 것이 아니라, jre가 실행
// 운영체제에 무관하게 jdk, jre가 있다면 실행가능(일종의 에뮬)
// 자바의 장점 : 호한성
// 자바의 단점 : 느림
// 아이폰은 네이티브
// 자바의 배포 형식 : jar

// jar : 자바로 작성한 코드들을 모아 놓은 것

// 자바는 객체지향언어 -> 모든 것은 객체다
// 코드를 실행하려면 main필요 -> main을 만드려면 클래스부터 만들어


public class Test1 {
	public static void main() {
		// 자바의 타입 : 정수, 실수, boolean, 문자열
		int a = 100;
		double f = 3.14;
		boolean b = 5>3;
		String str = "aaaa";
	}
}
