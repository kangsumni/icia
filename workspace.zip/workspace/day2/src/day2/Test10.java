package day2;

public class Test10 {
	
	public static void main(String[] ar) {
		// 상수 : const, final
		// final로 선언하면 변경금지
		final int COUNT = 10;
		int sumOfKor;
		final int SUM_OF_KOR;
		// 첫글자만 대문자면 클래스
		// 모든글자가 대문자면 상수
		// 클래스도 상수도 아니면 반드시 소문자로 시작해야 한다
		// 문법이 아니라 관습
		
		// 참조변수 : 객체를 가리키는 변수. 4바이트
		
		
	}
}
