package day2;

public class Test6 {
	public static void main(String[] ar) {
		int kor = 75, eng = 75, math = 80;
		
//	System.out.println((kor+eng+marth)/3);
	// 평균을 구해서 출력하시오 -> 실수 안나옴
	// 정수+정수+정수 ->정수 230
	// 230/3 -> 76
	// avg = 76을 대입 -> 76.0
	double avg = (kor+eng+math)/3;
	System.out.println(avg);
	
	// 정수+정수+정수 ->정수 230
	// 230/3 -> 76.666666
	// avg = 76.666666을 대입 -> 76.666666	
	double avg1 = (kor+eng+math)/3.0;
	System.out.println(avg1);
	
	// 형변환 연산자(cast연산자) 이용
	double avg2 = (double)(kor+eng+math)/(double)3;
	System.out.println(avg2);
	}
}
