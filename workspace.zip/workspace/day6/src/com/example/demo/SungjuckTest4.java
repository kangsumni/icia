package com.example.demo;

//4. 생성자 만들기
class TV {
	// 0~100사이
	int 밝기;
	int 명암;
	// 생성자의 이름은 클래스 이름과 같다
	// 생성자는 return의 개념이 없다
	TV() {
		this.밝기 = 80;
		this.명암 = 70;
	}
}
public class SungjuckTest4 {
	public static void main(String[] args) {
		// 자동으로 만들어지는 생성자 : 기본 생성자
		// (default constructor)
		TV tv = new TV();
		System.out.println(tv.밝기);
	}
}
//생성자 - 초기값을 주는거
//setter - 값을 변경