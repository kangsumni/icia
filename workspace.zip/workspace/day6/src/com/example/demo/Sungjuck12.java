package com.example.demo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// annotation을 클래스에 적으면 클래스에, 필드에 적으면 필드에 적용
@Getter
@AllArgsConstructor		//매개변수 3개 생성자
@NoArgsConstructor
@Builder
class 학생 {
	@Setter
	private String 학교;
	private String 이름;
	@Setter
	private String 주소;
}
public class Sungjuck12 {
	// 코딩할 때 반복해서 만나는 문제들을 해결하는 방법을 패턴이라고 한다
	// 객체 생성의 난해함에 대처하는 패턴이 builder 패턴
	public static void main(String[] args) {
		학생 s1 = 학생.builder().학교("중학교").build();
		학생 s2 = 학생.builder().학교("홍길동").주소("학익동")
				.build();
	}
}
