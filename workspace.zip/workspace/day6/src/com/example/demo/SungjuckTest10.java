package com.example.demo;

// 생성자는 다양하게 제공하면 좋다 -> 그게 어렵다
class 양말{
	String 종류;
	String 색상;
	public 양말() {
		this.종류 = "스포츠";
		this.색상 = "검정";
	}
	public 양말() {종류= "스포츠"; 색상 = "검정";}
	public 양말(String 종류) {this.종류=종류; 색상 = "검정";}
	public 양말(String 종류, String 색상) {
		this.종류=종류; 
		this.색상 = "색상";}
	
}

class 양말2
	String 종류;
	String 색상;
// 자신의 다른 생성자를 this()라고 한다
	public 양말2() {this("스포츠","검정");}
	public 양말2(String 종류) {this.종류=종류; 색상 = "검정";}
	public 양말2(String 종류, String 색상) {
		this.종류=종류; 
		this.색상 = "색상";}

public class SungjuckTest10 {

}
