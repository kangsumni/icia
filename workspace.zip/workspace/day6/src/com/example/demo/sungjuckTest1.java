package com.example.demo;

// 클래스를 만들어야 한다. 어떻게 잘 만들까?? 객체지향 프로그래밍
// 웹 프로그래밍 기준 클래스의 종류 
// - 데이터를 저장하는 클래스(Value Object), 처리하는 클래스(Service)

class Sungjuck1 {
	// 필드와 게터, 세터 등 필수 메소드로 구성
	// 국, 영, 수, 반, 번호, 이름, 총점, 평균, 석차......
	// 객체 내부는 케이스를 씌워 보호해야한다 -> 캡슐화
	private String irum;
	private int kor;
	private int eng;
	private int math;
	private int tot;
}

class SungjuckService {
	// 총점 계산, 평균 계산, 석차 계싼, 성적표 출력..
	// 작성하는 방법이 어떤 기술을 사용하느냐에 따라 달라진다
	// 이쪽 동네는 스프링가서 생각하자
}

public class sungjuckTest1 {
	Sungjuck1 s = new Sungjuck1();
	s.kor = 70;
}
