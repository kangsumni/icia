package com.example.demo;

// 생성자 오버로딩
// 생성자는 객체 생성을 담당하고 이름이 정해져 있다
class 짜장 {
	String 사이즈;
	// 기본 생성자의 정의 : 매개변수 없는 생성자
	// 생성자가 없으면 기본 생성자를 자바가 자동으로 만든다
	public 짜장() {
		// 공장 초기값 같은 역할		
		this.사이즈 = "보통";
	}
	public 짜장(String 사이즈) {
		this.사이즈 = 사이즈;
	}
}
public class Sungjunck07 {
	public static void main(String[] args) {
		짜장 c1 = new 짜장();
		System.out.println(c1.사이즈);
		짜장 c2 = new 짜장("보통");
		System.out.println(c2.사이즈);
	}
}
