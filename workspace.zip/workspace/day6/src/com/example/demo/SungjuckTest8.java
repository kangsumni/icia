package com.example.demo;

// 메뉴, 샷으로 구성된 커피 클래스를 작성하시오
class Coffee {
	Stirng menu;
	int shot;
	int price;
	// 기본샷은 2, 기본가격 2500, 샷을 추가하면 500원 증가
	public Coffee() {
		this.menu = "아이스 아메리카노";
		this.shot = 2;
		this.price = 2500;
	}
	Coffee(String menu, int shot) {
		this.menu = menu;
		this.shot = shot;
		this.price = 2500;
		if(this.shot>2) {
			this.price = this.price + (shot-2)*500;
		}
	}
}
public class SungjuckTest8 {
	public static void main(String[] args) {
		Coffee c = new Coffee("아메리카노", 4);
		System.out.print(c.price);
	}
}
