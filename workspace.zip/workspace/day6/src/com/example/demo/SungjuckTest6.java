package com.example.demo;

// 모니터 클래스를 작성하시오. 모니터는 밝기와 크기 필드를 가지며
// 기본값은 밝기 80, 크기는 27이다

/*
 * 6. 빌드 도구
 * 자바프로그램은 내가 작성한 코드 + 의존성(dependency)으로 구성
 * 자바프로그래머는 코딩 실력도 중요하지만 설정 능력도 중요
 * 		보통 annotation으로 사용
 * 의존성을 포함해서 번역하는 것 : 빌드(ant, maven, gradle...)
 * 
 * 7. 메소드 오버로딩(overload)
 * 함수 이름은 중복불가능 -> 매개변수가 다르다면 중복 가능
 * public int sum(int a, int b) {
 * 		return a+b;
 * }
 * public double sum(int a, double b) {
 * 		return a+b;
 * }
 * public int sum(int a, int b, int c) {
 * 		return a+b+c;
 * }
 */
class Monitor {
	private int 밝기;
	private int 크기;
	
	public Monitor() {
		this.밝기 = 80;
		this.크기 = 27;
	}
	
	public int get밝기() {
		return 밝기;
	}
	public void set밝기(int 밝기) {
		this.밝기 = 밝기;
	}
	public int get크기() {
		return 크기;
	}
	
	
}
public class SungjuckTest6 {
	public static void main(String[] args) {
//		Monitor monitor = new Monitor();
//		System.out.println(monitor.밝기);
//		System.out.println(monitor.크기);
	}
}
