package com.example.demo;

//VO 작성하기
//1. 필드 작성
//2. 캡슐화		*****
//3. 값을 읽어오는 getter/값을 변경하는 setter
//4. 객체 생성을 담당하는 생성자 추가		*****

class Sample {
	// constructor : 객체를 new할 때 단 한번 실행되는 초기화 함수
	// 생성자 이름은 클래스 이름과 같다
	// 생성자가 없다면 자동으로 추가한다
}
public class SungjuckTest3 {
	public static void main(String[] args) {
		// 참조변수 sample는 null
		Sample sample;
		
		// 객체를 생성하려면 new 연산자와 생성자를 사용한다
		sample = new Sample();
		// Date data = new Date();
	}
}
