package com.example.demo;

// 생성자
class TV1 {
	int 밝기;
	int 명암;
	// 생성자는 객체를 생성하는 함수. XXXX 초기화하는 함수
	TV1() {
		init();
	}
	void init() {
		 밝기 = 70;
		 명암 = 80;
	}
}
public class SungjuckTest9 {
	public static void main(String[] args) {
		TV1 tv= new TV1();
		//막 가지고 논다
		
		tv.TV1();
	}
}
