package com.example.demo;

// VO 작성하기
// 1. 필드 작성
// 2. 캡슐화
// 3. 값을 읽어오는 getter/값을 변경하는 setter

class Sungjuck2 {
	private String name;
	private int kor;
	private int eng;
	private int tot;
	
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getTot() {
		return tot;
	}
	public void setTot(int tot) {
		this.tot = tot;
	}
	public String getName() {
		return name;
	}
	
}
public class SungjuckTest2 {
	public static void main(String[] args) {
		Sungjuck2 s = new Sungjuck2();
		System.out.println(s.getTot());
		s.setTot(100);
		System.out.println(s.getTot());
	}
}
