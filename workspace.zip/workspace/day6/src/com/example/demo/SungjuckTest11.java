package com.example.demo;

// 이름, 학교, 전화번호로 구성된 학생 클래스를 작성하시오
//  private, 생성자, 게터/세터
class Student {
	private String 이름;
	private String 학교;
	private String 전화번호;

	// VO -> 스프링에서는 Spring Bean
	// 스프링은 기본 생성자를 요구
	public Student() {	
	}
	public Student(String 이름, String 학교, String 전화번호) {
		this.이름 = 이름;
		this.학교 = 학교;
		this.전화번호 = 전화번호;
	}
	
	
}
public class SungjuckTest11 {
	public static void main(String[] args) {
		// 조합 가능한 생성자를 모두 만드는 것도 어렵고
		// 또 생성자를 제대로 사용하는 것도 어렵다(객체 생성이 난해하다)
		
		
	}
}
