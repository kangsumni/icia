package com.example.demo;

// VO 클래스 만들기
// 1. 관련된 필드를 모은다
// 2. 캡슐화
// 3. 게터,세터
// 4. 기본 생성자

class 계좌 {
	private String 계좌번호;
	private int 잔액;
	public int get잔액() {
		return 잔액;
	}
	public void set잔액(int 잔액) {
		this.잔액 = 잔액;
	}
	public String get계좌번호() {
		return 계좌번호;
	}
	
	public 계좌() {
		this.계좌번호 = "1234";
		this.잔액 = 0;
	}
	
}
public class SungjuckTest5 {
	public static void main(String[] args) {
		계좌 account = new 계좌();
		
	}
}
