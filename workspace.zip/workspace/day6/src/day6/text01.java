package day6;


/*
 * 1. 자바의 구성 : JRE(가상머신, JVM), JDK  *****
 * 자바 앱은 운영체제가 아니라 JRE 위에서 돌아간다
 * 따라서 JRE만 제공된다면 어느 시스템에서나 돌아갈 수 있다
 * 
 * 2. 자바의 역사 
 * Sun에서 개발, 2010년 오라클에서 인수
 * 오라클은 세계 최대의 database 회사
 * 
 * 3. 자바의 종류
 * Java ME : 모바일용 자바. 망했다
 * Java SE 
 * Java EE : 기업용자바 (주영역에서 스프링에게 밀림) -> 
 * 			 오라클에서 포기 -> Jakarta EE 
 * 
 * 4. 언어의 종류
 * 기계어(machine language)
 * 		컴퓨터가 이해가능한 이진수 언어.
 * 		low-level 언어
 * 고급언어(high-level)
 * 		전산에서low, high는 기계에 가깝다 또는 멀다라는 의미
 * 		기계어로 번역해야만 실행 가능
 * 
 * 5. 번역프로그램의 종류		*****
 * compiler : 번역 후 결과를 저장한 다음 실행 ex) exe 파일 생성
 * interpreter : 매번 새로 번역 ex) flash 게임, html, js
 * 
 * 6. 빌드 도구
 * 자바프로그램은 내가 작성한 코드 + 의존성(dependency) 으로 구성
 * 자바프로그래머는 코딩 실력도 중요하지만 설정 능력도 중요
 * 		보통 annotation으로 사용		
 * 		ex) @Data
 * 의존성을 포함해서 번역하는 것 : 빌드 (ant, maven, gradle...)
 */
public class text01 {

}
