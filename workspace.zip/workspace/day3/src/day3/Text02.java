package day3;

public class Text02 {
/*
 * 자바에서 이름은 중복 불가능하다 -> 이름이 겹치면??? 오류???
 * student1.kor
 * student2.kor 
 * 이름에 소속을 만들자(예를 들어 객체)-> 이름이 겹쳐도 된다
 * 클래스 이름이 겹친다면? -> 패키지(폴더)
 * 		java.util.date, java/sql.Date
 * 
 * 패키지 이름은 겹치지 않아야한다. 어떻게???
 * 개발자가 속한 웹주소를 거꾸로 사용한다
 * ex)
 * ai.naver.com -> com.naver.ai.Date
 * js.icia.co.kr -> kr.co.icia.js
 * */
}
