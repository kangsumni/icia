package day3;

public class Text01 {

//	1- 'use strict'
	
/*
	const ar = {name: '홍길동', name: '전우치'};
	
*/
	
	
}
