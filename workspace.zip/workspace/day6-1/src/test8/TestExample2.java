package test8;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 게시판(Board) 클래스를 작성하시오
@Getter
@AllArgsConstructor
@Builder
@NoArgsConstructor
class Board {
	private int 글번호;
	@Setter
	private String title;
	@Setter
	private String content;
	private String writer;
	private LocalDate writeday;
	@Setter
	private int readcnt;
	private boolean enabled;
	private boolean hit;
//	private ArrayList<String> image;
	
//	private String 작성자;
//	private String 작성일;
}
public class TestExample2 {
	public static void main(String[] args) {
		// 게시판 사용자는 제목과 내용만 작성
		// 백엔드에서 글번호, 글쓴이, 글쓴시간, 조회수를 넣는다
	}
}
