package test7;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// 아이디, 비밀번호, 이메일로 구성된 Member 클래스를 작성하시오
@Getter
@AllArgsConstructor
@Builder
@NoArgsConstructor		// spring에서 필요
@ToString
class Member {
	private String username;
	@Setter
	private String password;
	@Setter
	private String email;
	
}

public class TestExample1 {
	public static void main(String[] args) {
		// 아이디는 spring, 비밀번호는 1234인 Member 객체 생성
		Member m = Member.builder().password("1234")
				.username("spring").build();
		// 아이디는 summer, 비밀번호는 1234, 이메일은
		// summer@naver.com인 Member 객체 생성
		Member m2 = Member.builder().password("1234")
				.email("summer@naver.com").username("summer")
				.build();
		System.out.println(m2);
	}

}
