package test6;

import lombok.AllArgsConstructor;
import lombok.Builder;

@AllArgsConstructor
@Builder
class StudentA {
	private String irum;
	private String address;
	private String school;
}
@AllArgsConstructor
@Builder
class StudentB {
	private String irum;
	private String address;
	private String school;
}

public class BuilderTest1 {
	public static void main(String[] args) {
		StudentA s1 = new StudentA("홍길동", "학익동", "학익고등학교");
		StudentA s2 = new StudentA("학익동", "학익고등학교", "홍길동");

	
		StudentB s3 = StudentB.builder().
				irum("홍길동").school("학익고등학교").build();
	}
}
