package test2;

// static 멤버 : 정적 필드 -> 클래스 소속의 변수
class TV {
	static String vendor = "인천전자";
	String modelName;
	int price;
}
public class ConstructorTest {
	public static void main(String[] args) {
		// 객체마다 다른 값, 객체들이 공유하는 값
		// 모든 객체의 공통변수 -> static
		// static은 객체가 아닌 클래스 소속
		System.out.println(TV.vendor);
		TV tv1 = new TV();
		TV tv2 = new TV();
		TV tv3 = new TV();
	}
}
