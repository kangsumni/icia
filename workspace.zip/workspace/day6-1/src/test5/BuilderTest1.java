package test5;

// 디자인 패턴 : 프로그래밍에서 반복되어 나오는 문제들에 대한 해결책
// Builder 패턴 - 객체 생성의 난해함에 대처하는 패턴
public class BuilderTest1 {
	public static void main(String[] args) {
		StudentA s1 = new StudentA("홍길동", "학익동", "학익고등학교");
		StudentA s2 = new StudentA("학익동", "학익고등학교", "홍길동");
		
		// Builder는 생성자를 대체하는 패턴
		StudentB s3 = StudentB.builder().
				irum("홍길동").school("학익고등학교").build();
	}
}
