package test3;

// 제조사를 출력하는 메소드를 추가하자
class TV {
	static String vendor = "인천전자";
	String modelName;
	int price;
	public static void printVendor() {
		System.out.println(vendor);
	}
}
public class ConstructorTest {
	public static void main(String[] args) {
		System.out.println(TV.vendor);
		//객체를 만들고 제조사를 출력
//		TV tv1 = new TV();
//		tv1.printVendor();
		
		// 정적 메소드는 객체없이 클래스 이름으로 사용할 수 있다
		// !!! 단 정적 메소드는 정적 필드에만 접근 가능하다
		TV.printVendor();
	}
}