package test4;

// 필드 초기화하는 순서

class TV {
	// 1. 인스턴스 초기화 : 필드를 만들면서 바로 값을 준다
//						모든 객체를 똑같은 값을 가지게 된다
	// 2. 정적 초기화 : 정적 필드를 초기화한다
//					정적 필드를 인스턴스 초기화해도 상관없다
//					코드가 두줄이상인 경우 주로 사용
	// 3. 생성자
	
	int price = 500000;
	static String vendor;
	String modelName;
	
	static {
		System.out.println("정적 초기화 영역");
		vendor = "인천전자";
	}
	TV() {
		System.out.println("생성자 호출");
	}
}
public class ConstructorTest {
	public static void main(String[] args) {
	}
}
