package test1;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

// 매개변수를  Parameter 또는 Argument 라고 한다
// 생성자가 없으면 자바가 기본생성자 추가. 있으면 짤 없다
@AllArgsConstructor
@NoArgsConstructor
class TV {
	String vendor;
	String modelName;
	int price;
}
public class ConstructorTest {
	public static void main(String[] args) {
		TV tv = new TV();
	}
}
