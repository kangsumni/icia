package test9;

public class TestExample {
	public static void main(String[] args) {
		// 인증코드를 20자를 생성하자 -> random()
//		OTP, 보안카드
		RandomStringUtils.rand
	}
}
