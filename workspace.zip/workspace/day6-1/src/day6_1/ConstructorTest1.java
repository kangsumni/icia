package day6_1;

import lombok.AllArgsConstructor;

//인천전자가 생산하는 TV
@AllArgsConstructor
class TV {
	String vendor;
	String modelName;
	int price;
}
public class ConstructorTest1 {
	public static void main(String[] args) {
		// 기본생성자를 이용한 객체 생성
		// TV 클래스의 생성자는 어디있나?
		// 자바는 생성자가 없는 클래스에 기본 생성자를 자동으로 추가한다
		//  	public TV() { }
		 
		TV tv = new TV();
	}

}
