package day4;

//필드에는 인스턴스 필드와 정적 필드가 있다
class KorArmy {
	// static(정적)은 하나만 만들어지고 모든 객체들이 공유
	// 클래스 소속의 필드다
	static String 국가;
	String 군번;
	String 이름;
}
public class Text02 {
	public static void main(String[] args) {
		//{"한국", "1234", "홍길동"}, {"한국", "1111", "임꺽정"}
		KorArmy a1 = new KorArmy();
		a1.국가 = "한국";
		a1.군번 = "1234";
		a1.이름 = "홍길동";
		
		KorArmy a2 = new KorArmy();
		a2.국가 = "한국";
		a2.군번 = "1111";
		a2.이름 = "임꺽정";
		
		a2.국가 = "미국";
		a2.이름 = "전우치";
		System.out.println(a1.국가);
		System.out.println(a1.이름);
	}
}
