package day4;

public class Text01 {

	class Address {
		String 우편번호;
		String 기본주소;
		String 상세주소;
		String 전화번호;
	}
	
	class Customer {
		String irum;
		String email;
		String username;	//키
		String password;
		ArrayList<Address> address;
		ArrayList<String> profile;
	}
	
	//계조의 유저
	class User {
		
	}
	
	//계좌
	class Account {
		
	}
	
	public class Test4 {
}
