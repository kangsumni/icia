package day5;

public class Text04 {
	public static void main(String[] args) {
		Sample s1 = new Sample();
		Sample s2 = new Sample();
		// 객체는 heap에 만들어진다
		// heap은 필요할 때 생성, 필요없어지면 해제하는 메모리
		// 힙에 만들어지는 객체에 이름을 붙일 수 없다
		// -> stack에 있는 참조변수로 간접조작을 한다
		System.out.println(s1.no);
		
		// 변수와 함수는 stack에 만들어진다
		// stack은 문법에 따라 운영되는 자동 영역
		// 프로세스는 소량의 전용메모리를 가진다(stack)
		
		System.out.println(Sample.countOfobject);
	}
}
