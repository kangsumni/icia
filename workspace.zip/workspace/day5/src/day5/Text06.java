package day5;

// 메소드는 필드를 처리 -> 파라미터나 리턴이 없는 경우가 대부분이다
// 백에서 사용하는 메소드는 기본이 getter/setter인 경우가 대부분
class Saram1 {
	int nai;
	String name;
	int getNai() {
		return this.nai;
	}
	void setNai(int nai) {
		this.nai = nai;
	}
	
	
}
public class Text06 {

}
