package day5;

// 가격을 포함하는 book클래스를 만들고 객체를 생성한 다음 가격을
// 20000원으로 하시오. 가격을 읽어와 출력하시오

//lombok의 @Data annotation으로 클래스에 게터/세터 추가
@Data
class Book {
	private String isbn;
	private String publicsher;
	private String writer;
	private String title;
	private Integer price;
}

public class Text08 {
	public static void main(String[] args) {
		
		Book book = new Book();
		book.setPrice(20000);
		System.out.println(book.getPrice());
	}
}
