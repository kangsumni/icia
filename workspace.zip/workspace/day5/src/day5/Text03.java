package day5;

public class Text03 {
	public static void main(String[] args) {
		//static은 객체들이 공유하는 멤버
		//객체소속이 클래스 소속(하나만 존재)
		//객체를 new하기 전부터 사용할 수 있
//		Sample s = new Sample();
		System.out.println(Sample.countOfobject);
		System.out.println(Math.PI);
//		System.out.println(Sample.name);
	}
}
