package day5;

class Sarma1 {
	// access modifier
	public int height;
	public int weight;
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
}
public class Text07 {
	public static void main(String[] args) {
		Saram1 s = new Saram1();
		s.setHeight(185);
		s.setWeight(75);
		
		// 지나가던 나님이 기분이 나빠
		s.height = 120;
	}
}
