package day5;

// 붕어빵틀 - 붕어빵을 찍어냈다면 찍어낸 붕어빵을 인스턴스(instance)
// 프로세스 : 실행된 프로그램 -> 프로그램의 인스턴스

class Sample {
	//객체들이 공유하는 정보 - static
	// 필드 인스턴스 초기화
	static int countOfobject = 0;
	int no;
	String name;
}
public class Text02 {
	// Sample 객체가 몇개나 생성되는지 알고싶다
	public static void main(String[] args) {
		Sample s1 = new Sample();
		s1.countOfobject++;
		Sample s2 = new Sample();
		s2.countOfobject++;
		System.out.println(Sample.countOfobject);
		System.out.println(Sample.countOfobject);
	}
}
