package day5;

class Student {
	int hakbun;
	String name;
	void print() {
		//객체지향 언어는 this를 가진다
		//자바의 this는 항상 소속된 객체 -> 따라서 생략 가능
		System.out.println(name);
	}
}
//자바는 클래스를 만든 다음 객체를 생성한다(객체지향)
//ES5까지는 클래스가 없다. ES6부터는 클래스를 지원한다
//백단에서는 객체를 처리 -> 검증 -> 클래스가 매우 중요하다
//프론트는 백에서 보내준 객체를 출력 (클래스가 그다지 중요하지 X)
public class Text01 {
	public static void main(String[] args) {
		for(int i=0; i<100; i++) {
			new Student();
		}
	}
}
