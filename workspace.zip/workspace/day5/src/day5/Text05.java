package day5;

public class Text05 {
	// 자바의 변수는 필드와 지역 변수로 나뉜다
	int x;					// heap
	static int y;
	public static void main(String[] args) {
		// 메소드의 변수의 지역 변수(클래스 소속이 아니다)
		int y;				// stack
	}
}
