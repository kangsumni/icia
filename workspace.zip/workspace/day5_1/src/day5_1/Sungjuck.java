package day5_1;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class Sungjuck {
	private String name;
	private int kor;
	private int eng;
	private int tot;
	private double avg;
}
