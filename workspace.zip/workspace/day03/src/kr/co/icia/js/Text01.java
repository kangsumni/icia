package kr.co.icia.js;

// 이 클래스의 풀 네임(FQN) : kr.co.icia.js.Test1
class Book {
	// 클래스는 객체를 찍어내는 설계도
}
public class Text01 {
	public static void main(String[] args) {
		// 기본타입, 참조타입 : 객체를 가리키는 변수
		
		// new를 이용해서 객체를 생성할 수 있다
		// const date = new Date();
		Book book = new Book();
		System.out.println(Math.PI);
		// 참조변수는 4바이트 정수(객체 번호)
		System.out.println(book.hashCode());
		
		int a=10, b=20;
		System.out.println(a+b);
		
		System.out.println(book.hashCode() + a);
		
		//js에서 객체를 만들면 기본 메소드들이 들어있다 ex)롯데햄
		//js에서 객체를 만드는 틀 -> prototype
		
		// 자바는 객체를 만드는 틀을 프로그래머가 만든다 ex)수제햄
		// 자바도 간단한 기본틀은 제공해준다(object)
	}

}
