package kr.co.icia.js;

// 연산자
public class Text05 {
	public static void main(String[] args) {
		//1. 단항연산 : !, ., ++, --
		//2. 이항연산
//				산술 " + - * / %
//				조건(비교) : >, >=, <, <=, ==, !=
//				논리 : &&, ||
		//3. 삼항연산
		//4. 대입연산  : +=, *=.......
	}
}
