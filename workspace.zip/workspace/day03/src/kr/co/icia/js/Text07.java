package kr.co.icia.js;

import java.util.ArrayList;

public class Text07 {
	public static void main(String[] args) {
		// 자바는 배열대신 ArrayList 클래스를 사용한다
		
		// 자바가 제공하는 클래스가 처음부터 사용가능 X
		// 현재 ArrayList는 아무거나 다 담을 수 있다
		ArrayList ar = new ArrayList();
		System.out.println(ar.size());
		
		ar.add(10);
		System.out.println(ar.size());
		
		// Integer만 담을 수 있는 ArrayList
		ArrayList<Integer> ar2 = new ArrayList<Integer>();
		
	}
}
