package kr.co.icia.js;

import java.util.Arrays;
import java.util.List;

public class Text9 {
	public static void main(String[] args) {
		List<Integer> ar = Arrays.asList(70, 90, 75, 80, 100);
		
		// ar의 합계를 출력하시오
		int sum = 0;
		for(int i=0; i<ar.size(); i++) {
			// (wrapper class)
			// 자바의 8개 기본타입에 대해 8개 클래스가 제공된다
			// 기본타입과 wrapper는 자동으로 수행된다
			sum = sum + ar.get(i);
		}
		System.out.println(sum);
	}
}
