package kr.co.icia.js;

public class Text06 {
	public static void main(String[] args) {
		int s = 75;
		
		// s가 70이상이면 합격, 아니면 불합격이라고 출력하시오
		if(s>=70) {
			System.out.println("합격");
		} else {
			System.out.println("불합격");
		}
	}
}
