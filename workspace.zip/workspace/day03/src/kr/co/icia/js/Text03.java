package kr.co.icia.js;

// 기본타입
public class Text03 {
	// 정수  : byte, short, int, long (표현범위)
	// 실수 	: float, double (정밀도)
	// 문자	: 2바이트 char utf-8
	// 문자표현방식 - MS-949(euc-kr), utf-8
	// boolean : 1바이트
	
	// String : 자바에서 new없이 객체를 만드는 유일한 케이스
	// String str = new String ("Hello");
	String str = "Hello";
	
}
