package kr.co.icia.js;

// 타입 변환
// 자바에서 타입은 프로그래머가 관리			  (명시적 형변환)
// 단 자바가 타입을 관리하는 경우는
// 서로 다른 타입을 연산할 때 넓은 타입으로 바뀐다 (묵시적 형변환)
public class Text04 {
	public static void main(String[] args) {
		long a = 10000000000L;
		
		long b = 1000;
		
		double avg = (double)(100+102)/2;
		// 100
		// 100.5
		// 100.0
		// 101
		
		System.out.println(avg);
	}
}
