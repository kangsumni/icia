package kr.co.icia.js;

import java.util.ArrayList;

public class Text08 {
	public static void main(String[] args) {
		ArrayList list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		// 항상된 for
		list.forEach((a)->{System.out.println(a);});
	}
}
