package kr.co.icia.js;

// 사람 클래스를 만들고 객체를 생성해 해시코드를 출력하시오

class People {
	String irum;
}

public class Text02 {
	public static void main(String[] ar) {
		People people = new People();
		System.out.println(people.hashCode());
		people.irum = "홍길동";
		
		//const people = {};
		//people.irum = '홍길동';
		
	}
}
