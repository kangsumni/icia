package kr.co.icia.js;

public class Text10 {
	// 제어문 : 동작 순서를 바꾼다
	// 조건문 - if, switch
	// 반복문 - for, while, do~while
	// 제어 - continue, break
	// 1~10사이 짝수를 출력하시오
	for(int i=1; i<10; i++) {
		if(i%2==0)
			System.out.println(i);
	}
	
	for(int i=1; i<=10; i++) {
		if(1%2==0)
			continue;
		System.out.println(i);
	}
	
	for(int i=2; i<=10; i+=2) {
		System.out.println(i);
	}
}
