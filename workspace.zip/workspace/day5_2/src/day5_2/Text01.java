package day5_2;

public class Text01 {

}
