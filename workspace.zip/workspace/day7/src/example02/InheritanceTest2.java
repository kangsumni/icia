package example02;

class 사람 {
	
}
class 학생 extends 사람 {
	
}
// is a 관계 (~는 ~다)
// A는 B다가 성립할 때 B가 부모, A가 자식
// 사람은 학생이다
// 학생은 사람이다

// 아이폰은 스마트폰이다 -> 아이폰은 스마트폰의 한 종류이다
// 부모는 범주, 카테고리 -> 부모는 추상적인 개념(추상적. abstract)
// 자식은 구체적인 클래스(구상적. concrete)
// 늑대는 개과다
class 스마트폰 {
	
}
class 아이폰 extends 스마트폰 {
	
}


public class InheritanceTest2 {

}
