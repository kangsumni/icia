package example02;

// 정적 멤버와 일반 멤버 사이에 접근하기
// 일반 멤버에는 this를 이용해 접근한다 -> new가 필수
// 정적 멤버는 this와 무관(this가 없다)
class Sample {
	int a;
	static int b;
	void generalFunc() {
		// 일반 메소드는 모든 멤버에 접근할 수 있다
		System.out.println(this.a);
		System.out.println(this.b);
		this.starticFunc();
	}
	static void staticFunc() {
		// 정적 멤버는 정적 멤버에만 접근할 수 있다
		System.out.println(this.a);		// 일반 멤버 접근 불가
		System.out.println(this.b);
		this.GeneralFunc();				// 일반 멤버 접근 불가
	}
}
public class Test03 {

}
