package example02;

import lombok.AllArgsConstructor;

// 정적 멤버
// 정적 필드와 메소드는 클래스 소속
// 객체를 사용하기 전부터 사용가능

// 덧셈하는 함수가 필요 -? 자바의 함수는 전부 메소드 -> 클래스 안에 집어넣기
@AllArgsConstructor
class MyMath1 {
	private int a;
	private int b;
	public int sum() {
		return a+b;
	}
}

public class Text01 {
	public static void main(String[] args) {
		MyMath1 obj = new MyMath1(11, 20);
		System.out.println(obj.sum());
	}
}

