package example02;

class MyMath2 {
	//MyMath2의 sum은 필드가 아니라 파라미터로 계산 후 리턴
	public int sum(int a, int b) {
		return a+b;
	}
}
class MyMath3 {
	// 진짜 상수
	final static double PI = 3.14;
	public static int sum(int a, int b) {
		return a+b;
	}
}
public class Test02 {
	public static void main(String[] args) {
		// 어차피 필드 사용안하는데 객체는 왜 만들어???
		MyMath2 obj1 = new MyMath2();
		obj1.sum(10,20);
		
		MyMath3.sum(10,20);
		System.out.println(MyMath3.PI);
	}
}
