package example02;

// 객체지향 구성요소
// 캡슐화(encapsulation) : 클래스를 만들어라
// 정보은닉(information hiding) : private으로 만들어라
// 상속(inheritance) : 재사용
// 다형성(polymorphism) : 상황에 따라 동작이 바뀐다
// 					  : overload, override

class Parent {
	// 부모 클래스는 재사용될 부품
	int a = 1000;
}
class Child extends Parent {
	// parent를 상속 -> 부모 것은 내꺼
	int b = 2000;
}
public class InheritanceTest1 {
	public static void main(String[] args) {
		// 실제로 사용하는 클래스는 반드시 자식이다
		Child child = new Child();
		System.out.println(child.a);
		System.out.println(child.b);
	}
}

// class 탐색기 extends 파일, 네트워크, Swing...
