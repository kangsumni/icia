package example04;

// 상속을 사용해야하는 이유 

// 1. 부모의 참조변수는 자식을 가리킬 수 있다
// 자식 객체로 작업한다. 하지만 참조변수는 항상!!! 반드시!!! 부모

// 2. 부모를 처리할 수 있다면 자식도 처리할 수 있다
//	부모를 처리하는 메소드는 자식도 처리할 수 있다

class Parent {
	
}
class Child extends Parent{
	
}
public class Test01 {
	public static void main(String[] args) {
		// 부모의 참조변수는 자식을 가리킬 수 있다. 왜?
		Parent p = new Child();
		Child c = new Parent();
		
		// 자식의 참조변수로 자식 가리키면 되는 거 아냐???
		// 스마트폰 바꿔주세요...아버지....
		// S22 s22 = new S22();
		// s22 = new 아이폰13맥스();
		
		// 스마트폰 smartPhone = new S22();
		// smartPhone = new 아이폰13맥스();
		
		// 삼각형 obj1 = new 삼각형();
		// 사각형 obj2 = new 사각형();
		
		// 도형 obj1 = new 삼각형();
		// 도형 obj2 = new 사각형();
	}
}
