package example04;

import java.util.ArrayList;

class 도형 {
	
}
class 삼각형 extends 도형 {
	
}
class 사각형 extends 도형 {
	
}
public class Test02 {
	public static void main(String[] args) {
		ArrayList<삼각형> tList = new ArrayList<>();
		ArrayList<사각형> tList = new ArrayList<>();
		
		ArrayList<도형> list = new ArrayList<>();
		list.add(new 삼각형());
		list.add(new 사각형());
		
		// 정규직, 계약직, 임시직 사원이 있다고 해보자
		// 정규직 따로, 계약직 따로, 임시직 다로 관리할 건지
		// 아니면 사원으로 관리할 건지...
		
		ArrayList<정규직> 정규직사원들;
		ArrayList<계약직> 계약직사원들;
		ArrayList<임시직> 임시직사원들;
		
		ArrayList<사원> 사원들;
	}
}
