package example05;

// SOLID
// 단일 책임 원칙 (Single Responsibility Principle)
//  클래스는 한가지 책임(관심, 관심사)만을 가져야 한다
// 개방 폐쇄 원칙 (Open Closed Principle)
//  기능의 개선에 대해서는 열려있고 코드의 변경에 대해서는 닫혀있다
// 	안드로이드/iOS가 업데이트되면 나는 그 혜택을 받아야한다
//  그런데 내가 뭔가를 하기는 싫어
// 리스코프 치환 원칙 (Liskov Substitution Principle)
// 나머지 두개는 나중에
public class Test01 {

}
