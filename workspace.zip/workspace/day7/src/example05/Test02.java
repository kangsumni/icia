package example05;

import java.util.ArrayList;
import java.util.List;

class Pet {
	public void play() {
		System.out.println("뛰어놉니다");
	}
}
class Cat extends Pet {}
class Dog extends Pet {}
class Cow extends Pet {}

//==================
class 고양이{}
class 개{}
//==================

public class Test02 {
	public static void main(String[] args) {
		List<Pet> list = new ArrayList<>();
		list.add(new Cat());
		list.add(new Dog());
		for(Pet pet:list) {
			pet.play();
		}
		//==================
		List<고양이> cList = new ArrayList<>();
		List<개> dList = new ArrayList<>();
	}
}
