package example03;

class Grand {
	private String name;
	public Grand(String name) {
		this.name = name;
	}
}

class Parent extends Grand {
	private String name;
	public Parent(String gname, String name) {
		super(gname);
		this.name = name;
	}
}

class Child extends Parent {
	private String name;
	public Child(String gname, String pname, String name) {
		super(gname, pname);
		this.name = name;
	}
}

public class Test03 {
	public static void main(String[] args) {
		Child child = new Child("조부모", "부모", "자식");
	}
}
