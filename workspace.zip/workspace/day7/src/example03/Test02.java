package example03;

// 객체 초기화

// 객체지향 구성요소 : 캡슐화, 정보은닉, 상속, 다형성
// 객체지향 설계원칙(SOLID)
// 1. 단일책임원칙(Single Responsibility Principle)
// 		1인분만 해라(책임, 관심 - concern)
class Parent {
	private int pMoney;
	public Parent(int pMoney) {
		this.pMoney = pMoney;
	}
}

class Child extends Parent {
	private int cMoney;
	public Child(int pMoney, int cMoney) {
		// 각 클래스는 자신의 필드를 책임진다(SRP)
		// 자식 클래스는 cMoney 초기화. pMoney는 Parent가 초기화
		// 자식은 부모의 생성자를 호출한다 -> 생성자 첫줄에서만 가능
		super(pMoney);
		this.cMoney = cMoney;
	}
}
public class Test02 {
	public static void main(String[] args) {
		Child child = new Child(2000,1000);
	}
}

// this = this + super
// Child의 필드 : super.pMoney, this.cMoney
