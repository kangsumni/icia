package example03;

import lombok.Getter;

// 상속의 코드의 재사용 : extends
// 부모 클래스 : super class, base class, parent class
class 부모 {
	private int pMoney;
}
// 자식 클래스 : Sub class(x), Derived(파생) class, Child class
@Getter
class 자식 extends 부모 {
	private int cMoney;
}
public class Test01 {
	public static void main(String[] args) {
		자식 obj = new 자식();
		//obj는 cMoney만을 가진다
		
		obj.getPMoney();
		// 부모의 private은 자식에게도 private
		// 자식은 부모의 private에 접근할 수 없다
	}
}
