package day7;

import org.apache.commons.lang3.RandomStringUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Car2 {
	// 우리가 현대자동차라면 모든 company는 현대자동차
	// 그러면 굳이 객체마다 값을 집어넣을 필요가 없다
	public final static String company = "현대자동차";
	private String model;
	private String color;
	private int maxSpeed;
	private int speed;
}
public class Text02 {
	public static void main(String[] args) {
		// 인증코드를 20자를 생성하자 -> random()
		String s = RandomStringUtils.randomAlphabetic(20);
		System.out.println(s);
	}
}
