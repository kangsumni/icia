package day7;

class Marine {
	static int 체력;
	int 현재체력;
	int 사정거리;
}

// 모든 마린의 전체체력은 40이다 -> static
// 만약 final int 체력;로 적었다면 무슨 뜻
//		마린마다 전체체력이 다르다

// 마린의 사거리를 업그레이드한 경우
// 모든 마린의 사거리가 바뀌는 경우 -> static int 사정거리;
// 업그레이드 이후에 생산한 마린의 사거리만 바뀌는 경우 -> final int;
// 

public class Text04 {

}
