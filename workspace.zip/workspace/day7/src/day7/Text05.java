package day7;

class 자금마련대출 {
	// 기본금리 3%, 신용에 따른 가산 금리 0~3%
	// static을 붙이면 공유하는 값으로 변경 가능
	static double basicInterest = 0.03;
	final double interest;
	
	public 자금마련대출() {
		//신용도에 따라 가산 금리를 계산
		interest = basicInterest + 0.01;
	}
}
public class Text05 {

}
