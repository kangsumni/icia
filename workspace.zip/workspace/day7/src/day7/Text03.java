package day7;

// final : 변경 금지
// static : 공유

class 우리최고적금 {
	//금리가 4.5% ~~와 가입하세요
	//모든 우리최고적금 통장의 금리는 4.5%
	static double interest = 0.045;		//8byte
}

class 우리집마련대출 {
	// 대출 금리는 5%이고 변경 가능하다(가변 금리)
//	double interest = 0.05;
	
	// 대출금리가 5% 고정 금리라면
	final double interest = 0.05;
}

class 신용대출 {
	// 대출금리는 신용에 따라 다르다. 그리고 고정금리다
	// final은 instance 초기화 또는 생성자에서 초기화가 가능
	final double interest;
	public 신용대출(double interest) {
		this.interest = interest;
	}
}
public class Text03 {
	public static void main(String[] args) {
		// 우리최고적금 계좌가 1만개있다. interest의 개수는?
		
		// 우리집마련대출이 1만개있다. interest의 개수는?
	}
}
