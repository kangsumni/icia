package day7;

import org.apache.commons.lang3.RandomStringUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Car1 {
	// 필드 -> getter/setter, 생성자 -> 처리(Service 클래스)
	private String company;
	private String model;
	private String color;
	private int maxSpeed;
	private int speed;
}
public class Text01 {
	public static void main(String[] args) {
		// 인증코드를 20자를 생성하자 -> random()
		String s = RandomStringUtils.randomAlphabetic(20);
		System.out.println(s);
	}
}
