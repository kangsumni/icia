package practice01;

import java.util.ArrayList;
import java.util.List;

class 동물원 {
	public void print() {
		System.out.println("부모 메소드");
	}
}

class 호랑이 extends 동물원 {
	public void print() {
		System.out.println("호랑이");
	}
}
class 말 extends 동물원 {
	public void print() {
		System.out.println("말");
	}
}
public class Practice01 {
	public static void main(String[] args) {
	List<동물원> list = new ArrayList<>();
	list.add(new 호랑이());
	list.add(new 말());
	for(동물원 s:list) {
		s.print();
	}
	}
}
