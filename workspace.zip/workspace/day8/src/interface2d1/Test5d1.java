package interface2d1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

// 클릭 이벤트를 처리하자
// js의 경우 $(선택자).click(function() {} );
// 자바에서는 actionPerformed 메소드를 사용 -> ActionListener

// $(선택자).click(function() {
//	console.log("버튼을 클릭했어요");
//	}
// (function~ 했어요");
class MyFrame extends JFrame implements ActionListener {
	private JButton btn = new JButton("클릭하세요");
	public MyFrame() {
		add(btn);
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("버튼을 클릭했어요");
	}
}
public class Test5d1 {
	public static void main(String[] args) {
		new MyFrame();
	}
}
