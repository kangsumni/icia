package override3;

import java.util.ArrayList;
import java.util.List;

// 오버라이드 적용
class Shape {
	public void print( ) {
		System.out.println("부모 메소드");
	}
}
class Rect extends Shape {
	public void print() {
		System.out.print("사각형 출력");
	}
}
class Triangle extends Shape {
	public void print() {
		System.out.println("삼각형 출력");
	}
}
class Circle extends Shape {
	public void print() {
		System.out.println("원 출력");
	}
}
public class Test4 {
	public static void main(String[] args) {
		List<Shape> list = new ArrayList<>();
		list.add(new Rect());
		list.add(new Triangle());
		list.add(new Circle());
		//==========================
		for(Shape s:list)
			s.print();
	}
}
