package override3;

import java.util.ArrayList;
import java.util.List;

// 오버라이드
class 탈것 {
	public void run() {
		System.out.println("달려갑니다");
}
class 버스 extends 탈것 {
	}
}
class 기차 extends 탈것 {
}


class 비행기 extends 탈것 {
	// 오버라이드는 메소드 재정의
	// 부모와 자식간에 똑같은 메소드를 재정의하면 자식것이 실행된다
	public void run() {
		System.out.println("비행기가 날아갑니다");
	}
}
public class Test3 {

	public static void main(String[] args) {
		List<탈것> list = new ArrayList<>();
//		list.add(new 버스());
		list.add(new 기차());
		list.add(new 비행기());
		
		for(탈것 v:list)
			v.run();
		
		
	}
}