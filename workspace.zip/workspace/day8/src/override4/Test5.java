package override4;

// 부모클래스는 구체적인 내용이 없고 추상적이다
// 부모클래스는 자식들이 사용할 메소드의 이름을 정해주는 역할을 수행

// 부모클래스에 구체적인 내용이 들어갈 필요가 없다
// - 부모클래스의 내용은 자식들이 공유한다... 의미없다

// 추상 메소드 : {}없는 메소드 -> 구현하지 않고 이름만 정해준다
// 추상 클래스 : 추상 메소드를 하나이상 가진다. 객체 생성이 
// 자바에서 추상클래스는 abstract 키워드를 붙이지 않으면 오류 처리

// 추상(abstract) 클래스 <---> 구상(concreate)클래스
// 부모 반드시 추상클래스
abstract class Saram {
	public abstract void insa();
}
class Hakseng extends Saram {
	@Override
	public void insa() {
		System.out.println("안녕하세요");
		
	}
	// 에러를 냄으로써 메소드 이름을 가르쳐준다
}
public class Test5 {

}
