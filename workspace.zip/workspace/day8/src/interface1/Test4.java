package interface1;
// 번역기 팀 : 많은 클래스를 만들겠지...

interface 번역기 {
	public String 번역(String src, String dest, String msg);
}
class korToEng implements 번역기 {
	
}

// 번역기를 사용하는 앱 팀 : 
class App {
	private 번역기 translator = new KorToEng(); //interface사용법
	public void 번역수행() {
		System.out.println(translator.번역(null, null, null));
	}
}
public class Test4 {

}
