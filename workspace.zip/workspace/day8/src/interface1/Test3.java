package interface1;

import java.util.ArrayList;
import java.util.List;

// 오버라이드 적용
class 도형 {
	public void print() {
		System.out.println("부모 메소드");
}
class 사각형 extends 도형 {
	public void print() {
		System.out.println("사각형 출력");
	}
}
class 삼각형 extends 도형 {
	public void print() {
		System.out.println("삼각형 출력");
	}
}

//==================================================
public class Test3 {

	public static void main(String[] args) {
		List<도형> list = new ArrayList<>();
		list.add(new 사각형());
		list.add(new 삼각형());
		
		for(도형 s:list)
			s.print();
		
		
	}
}