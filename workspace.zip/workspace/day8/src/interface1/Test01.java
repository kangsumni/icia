package interface1;

// 부모는 추상적인 설계도, 스펙
// 추상 클래스 자체는 단순히 추상 메소드를 가지는 클래스란 의미 뿐
// 설계도 목적으로 사용하기 위해 추상 메소드만을 가지는 클래스를 만들자
// (사실은 추상 메소드 + 상수)

interface Shape {
	public void print();
}
class Rect implements Shape {
	@Override
	public void print() {
		System.out.println("사각형 출력");
		
	}
}

public class Test01 {

}
