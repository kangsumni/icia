package interface1;

// implements를 implements 상속이라고 부르기도 한다
/*
 * interface Parent { public void func(); - 추상메소드	}
 * 
 * interface Child extends Parent { }
 * interface Child2 implements Parent { }
 */

	interface Parent { public void func();}
	
	interface Child extends Parent { }
	
	// 설계도 -> default 구현 클래스 -> 오버라이드
	// Servlet : 서버에서 실행되는 자바 클래스
	interface Sevlet {
		public void init();			// 초기화
		public void service();		// 실제 작업
		public void destory();		// 뒷정리
	}
	abstract class HttoServlet implements Servlet {
		
	}
	class 아이폰13맥스 extends 아이폰 {
		
	}
public class Test2 {

}
