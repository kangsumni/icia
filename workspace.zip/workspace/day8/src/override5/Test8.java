package override5;

// 오버로드 : 유사한 기능들의 이름을 같게 해라
// - 동영상 재생, 음악 재생, 블루레이 재생 모두 play()
//		play(동영상), play(음악), play(블루레이)
// - 내 모니터에 출력, 파일로 저장, 상대방 모니터에 채팅 출력 println()
// - 반드시 파라미터가 달라야 한다(리턴은 오버로드와 상관없다)

class Base {
	public void sum(int a) {	}
}
class Derived extends Base{
	//super.sum과 this.sum이 오버로드
	public void sum(int a, int b) {		}
	// super.sum과 오버라이드
	public void sum(int a) {	}			
	// 14라인 sum과 오버로드
	public void sum(int a, int b, int c) {		}
	// super.sum과 오버라이드긴 한데 16라인 sum과 충돌
	public void sum(int a) {	}
}
public class Test8 {

}
