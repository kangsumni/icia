package override5;

// 오버로드와 오버라이드

class Parent {
	public void run() {
		
	}
}

class Child extends Parent {
	// Child 클래스는 run 메소드를 몇개 가진다?? 2개
	// this : super.run(), this.run()
	public int run() {}					//override 위반
	public void run(int x) {} {			//overload
		
	}
}
public class Test7 {

}
