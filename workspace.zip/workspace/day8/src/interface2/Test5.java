package interface2;

import javax.swing.JButton;
import javax.swing.JFrame;

// 클릭 이벤트를 처리하자
// js의 경우 $(선택자).click(function() {} );
// 자바에서는 actionPerformed 메소드를 사용 -> ActionListener
class MyFrame extends JFrame {
	private JButton btn = new JButton("클릭하세요");
	public MyFrame() {
		add(btn);
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
}
public class Test5 {
	public static void main(String[] args) {
		new MyFrame();
	}
}
