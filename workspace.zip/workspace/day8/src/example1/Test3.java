package example1;

// 클래스 확장의 문제
class 도형 {
	int i;
}
class 삼각형 extends 도형 {
	int j;
}
class 사각형 extends 도형 {
	int k;
}
public class Test3 {
	public static void main(String[] args) {
		// 참조변수는 대부분, 주로 부모를 사용한다
		// 자식 참조변수는 자기 자신만 가리킬 수 있다
		// 부모 참조변수는 모든 자식을 가리킬 수 있다(flexble)
		도형 obj = new 삼각형();
		System.out.println(obj.i);
		//System.out.println(obj.j);
		// 부모형 참조변수는 자식으로 형변환이 가능하다
		System.out.println(((삼각형)obj).j);
		
		obj = new 사각형();
		System.out.println(obj.i);
		//System.out.println(obj.k);
		System.out.println(((사각형)obj).k);
	}
}
