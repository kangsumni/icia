package example1;

// 구조적 프로그래밍 : 프로그램을 기능(함수)으로 분할
//- jQuery : 기능들의 집합. append, appendTo

// 회원레벨 클래스
// - 필요한 데이터와 필요한 작업을 스스로 알아서 하면 된다
// - 회원 레벨이 뭐뭐뭐 있어?
// - 회원레벨이 승급하려면 조건이 뭐니??
public class Test01 {
	public static void main(String[] args) {
		String str = "1234";
		Level.getLevels();		//Normal Silver Gold
		Level.getLevelInfo("SILVER");
	}
}
