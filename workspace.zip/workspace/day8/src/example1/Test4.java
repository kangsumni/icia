package example1;

import java.util.ArrayList;
import java.util.List;

// 부모를 상속해 확장했을 때의 문제점
class Shape {
	
}
class Rect extends Shape {
	public void print() {
		System.out.println("사각형 출력");
	}
}
class Triangle extends Shape {
	public void output() {
		System.out.println("삼각형 출력");
	}
}
class Circle extends Shape {
	public void draw() {
		System.out.println("원 출력");
	}
}
public class Test4 {
	public static void main(String[] args) {
		List<Shape> list = new ArrayList<>();
		list.add(new Triangle());
		list.add(new Circle());
		//==========================
		for(Shape shape:list) {
			// instanceof : 참조변수가 가리키는 자식을 확인
			if(shape instanceof Rect)
				((Rect)shape).print();
			else if(shape instanceof Triangle)
				((Triangle)shape).output();
			else if(shape instanceof Circle)
				((Circle)shape).draw();
		}
	}
}
