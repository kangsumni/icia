package example1;

// 다형성 : 객체의 동작은 상황에 따라 달라져야 한다
// 오버로드(overload)
// 오버라이드(override)
public class Test5 {

}
