package override2;

import java.util.ArrayList;
import java.util.List;

import override3.기차;
import override3.버스;
import override3.비행기;
import override3.탈것;

//다형성 : 객체의 동작은 상황에 따라 달라져야 한다
//오버로드(overload)
//오버라이드(override)

// 자식 클래스에서 기능의 확장을 금지한다
class 탈것 {
	
}
class 버스 extends 탈것 {
	}
}
class 기차 extends 탈것 {
}

// 저 밑에 정말?...을 검증해보자
class 비행기 extends 탈것 {
	
}
public class Test3 {
	// extends(확장)는 금지되어야 한다
	public static void main(String[] args) {
		List<탈것> list = new ArrayList<>();
		list.add(new 버스());
		list.add(new 기차());
		list.add(new 비행기());
		
		// 형변환이 필요없다 + 탈것이 추가되도 문제없이 돌아간다
		for(탈것 v:list)
			v.run();
		
		
	}
}