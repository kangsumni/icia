package override1;

import java.util.ArrayList;
import java.util.List;

//다형성 : 객체의 동작은 상황에 따라 달라져야 한다
//오버로드(overload)
//오버라이드(override)

// 자식 클래스에서 기능의 확장을 금지한다
class 탈것 {
	
}
class 버스 extends 탈것 {
	public void drive() {
		System.out.println("버스가 달려갑니다");
	}
}
class 기차 extends 탈것 {
	public void go() {
		System.out.println("기차가 달려갑니다");
}

public class Test01 {
	// extends(확장)는 금지되어야 한다
	public static void main(String[] args) {
		List<탈것> list = new ArrayList<>();
		list.add(new 버스());
		list.add(new 기차());
	}
}
