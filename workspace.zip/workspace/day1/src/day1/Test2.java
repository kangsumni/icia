// 객체는 80년대 등장. 객체 기반 코딩을 객체 지향 프로그래밍이라고 한다
// - JS는 const s1 = {irum: '홍길동', nai:20}
//		  const s2 = {irum:'전우치', nai:20, tel:'0101111'}
// 1. JS에서 객체는 선택 사항 -> 자바는 모든 것이 객체
// - 즉 자바의 함수는 무조건 메소드다
// 2. class : 객체를 찍어내는 틀
// - 틀을 만든 다음 new 명령어를 객체를 찍어낸다
// - 모든 객체는 똑같이 생겼다(값이 아니라 멤버)
// - 붕어빵틀 클래스를 가지고 붕어빵을 찍어낸다
package day1;

public class Test2 {
	public static void main(String[] ar) {
		System.out.println("강수민");
	}
}
