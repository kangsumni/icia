package day1;

// 타입
// 1. 기본타입 : 값을 직접 다룬다
// 2. 참조타입 : 리모컨, 모든 객체는 참조타입으로 간접 조작한다
public class Test5 {
	public static void main(String[] args) {
		// 기본타입 : 정수, 실수, 참거짓, 글자(글자 1개)
		System.out.println(1000);
		System.out.println(123.45);
		System.out.println(4>3);
		System.out.println('5');		// 글자
		System.out.println("5");		// 문자열(string):객체
	}
}
