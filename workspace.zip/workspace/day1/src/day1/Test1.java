package day1;

public class Test1 {
	public static void main(String[] ar) {
		System.out.println("Hello Java");
	}
}
