package day1;

// package : 클래스를 담은 폴더 -> 필수문법 -> 초보자가 어떻게 사용하지?
// 			지정안하면 프로젝트 이름과 똑같이 자동 생성한다
// 자바에서는 클래스 이름만이 대문자로 시작한다(문법이 아니라 전통)
public class Test3 {
	// 함수의 이름은 자유 -> jQuery의 경우 시작하는 ready 메소드
	// 					java에서 시작하는 main 메소드
	
	//void : 결과값이 없다
	public static void main(String[] ar) {
		// console. log()
		// System : 컴퓨터
		// System.out : 모니터
		// System.in : 키보드
		System.out.println("강수민");
	}
}
