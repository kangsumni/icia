package day1;

// 변수
public class Test6 {
	public static void main(String[] args) {
		// js는 타입이 동적. 값을 주면 값에 따라 타입이 정해진다
		// 값이 없으면 타입 판단을 유보 -> undefined
//		int a = 10;
		// 자바는 정적 타입(타입을 변경할 수 없다)
		int a = 10;
		double f = 3.14;
		boolean b = true;
		char ch = 'A';
		String str = "A";		// 준 기본타입정도 취급		
		
		System.out.println(f);
		
		// 자바의 기본타입은 객체가 아니다
		// 정수 : byte, short, int, long
		// 실수 : float, double
		// boolean, char
	}
}
