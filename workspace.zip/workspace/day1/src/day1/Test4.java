package day1;

// 80년대 객체지향 언어로 C++ 등장 -> 객체가 선택사양 -> 안써
// C++를 보고 자바는 무조건 객체를 필수로 하자
// - 모든 함수는 메소드

// 시대가 바뀌었다 -> 자바는 장황한 언어가 되버렸다
public class Test4 {
	public static void main (String[] ar) {
		System.out.print("안녕");
		System.out.println("안녕2");
		System.out.println("안녕3");
	}
}

// JS -> console.log();

